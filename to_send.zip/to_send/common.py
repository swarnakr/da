'''*************************************************************************
	> File Name: common.py
	> Author: yuansong
	> Mail: yuansongwx@outlook.com
	> Created Time: Mon 21 Oct 2019 01:46:28 PM EDT
 ************************************************************************'''
class Config:
    #Model
    backbone = 'mobilenet' #backbone name ['resnet', 'xception', 'drn', 'mobilenet']
    out_stride = 16 #network output stride

    #Data
#    all_dataset = ['Paris', 'Khartoum', 'Shanghai', 'Vegas','ShanghaiVegas']
#    dataset = 'ShanghaiVegas'
    all_dataset = [ 'Shanghai','Vegas']
    dataset = 'Shanghai'
    train_num_workers = 4
    val_num_workers = 2

    img_root = '/home/swarna/main/DomainAdaptation/spacenet' #'/usr/xtmp/satellite/spacenet/'
    patch_root = '/home/swarna/main/DomainAdaptation/spacenet_patches/'
    append_path = '/home/swarna/PycharmProjects/mobilenet/configs/ganDA'
    file_name_root = '/home/swarna/main/DomainAdaptation/' #'/home/home1/swarnakr/scriptln/DA/domains/'
    #Train
    batch_size = 16
    freeze_bn = False
    sync_bn = False
    loss = 'ce' #['ce', 'focal']
    epochs = 100000
    lr = 1e-3
    momentum = 0.9
    weight_decay = 5e-4
    lr_scheduler = 'cos'
    lr_step = 5
    warmup_epochs = 10


config = Config()
