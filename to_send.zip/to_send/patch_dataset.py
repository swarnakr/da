import os
from model.deeplab import *
import json
from data import spacenet
from torch.utils.data import DataLoader
import numpy as np
from common import config
import cv2
from matplotlib import pyplot as plt
import pdb

def mynonzero(arr, threshold=0.7, above=True):
    assert threshold <= 1.0 and threshold >= 0.0
    arr2 = arr.reshape(-1)
    if above:
        return len(arr2[arr2 != 0.0]) > threshold * len(arr2)
    else:
        return len(arr2[arr2 != 0.0]) < threshold * len(arr2)


def write_patches(patch_size = 80, split='train'):
    empty_patch_threshold = 0.7
    gt_definition_high_threshold = 0.7
    gt_definition_low_threshold = 0.3

    cities = ['Vegas', 'Shanghai']
    N = int(400 / patch_size)
    patch_names= {}
    patch_names[0] = []
    patch_names[1] = []
    for city in cities:
        #paths
        save_path = config.patch_root
        dir_path = os.path.join(save_path, city)
        patchname_gt_write_path = os.path.join(save_path, 'patchname_gt_{}_{}.json'.format(city,split))
        if not os.path.exists(dir_path):
            os.makedirs(dir_path)

        #read images and groundtruths
        train = spacenet.Spacenet(city=city, split='train',im_or_patch=1)
        tbar = DataLoader(train, batch_size=1, shuffle=False, num_workers=1)

        for i, sample in enumerate(tbar):
            image0, gt0 = sample['image'], sample['label']
            patch_num=0
            image = image0[0,:].numpy().transpose((1,2,0))
            gt = gt0[0,:].numpy()
            #slice into patches
            for x in range(N):
                for y in range(N):
                    image_slicer = (slice(int(x * patch_size), int((x + 1) * patch_size)),
                                    slice(int(y * patch_size), int((y + 1) * patch_size)),slice(None))
                    gt_slicer = (slice(int(x * patch_size), int((x + 1) * patch_size)),
                                 slice(int(y * patch_size), int((y + 1) * patch_size)))
                    i_patch = image[image_slicer]
                    g_patch = gt[gt_slicer]

                    #choose only non-empty patches with well defined groundtruth label
                    cond1 = mynonzero(i_patch, threshold=empty_patch_threshold, above=True)
                    cond2 = mynonzero(g_patch, threshold=gt_definition_high_threshold, above=True)
                    cond3 = mynonzero(g_patch, threshold=gt_definition_low_threshold, above=False)
                    cond4 = i_patch.shape == (80,80,3)
                    if cond1 and (cond2 or cond3) and cond4: #the patch should be non-empty and the groundtruth label should be easily decipherable

                        im_pathname = 'im{}_{}.png'.format(i,patch_num)
                        gt_pathname = 'gt{}_{}.png'.format(i, patch_num)

                        patch_names[cond2].append(im_pathname)

                        save_path = config.patch_root
                        image_write_path = os.path.join(save_path,city,im_pathname)
                        gt_write_path = os.path.join(save_path,city,gt_pathname)
                        cv2.imwrite(image_write_path,i_patch) #verify that is a numpy array that can be saved
                        cv2.imwrite(gt_write_path, g_patch)

                        patch_num += 1

        with open(patchname_gt_write_path, 'w') as f:
                json.dump(patch_names, f)

    return

def create_pairs(city,rand_start_index,split='train',times=3):
    save_path = config.patch_root
    patchname_gt_write_path = os.path.join(save_path, 'patchname_gt_{}_{}.json'.format(city,split))
    if os.path.exists(patchname_gt_write_path):
        f = open(patchname_gt_write_path)
        patch_names = json.load(f)
    else:
        print("The dictionary containing patch file locations and groundtruth labels was not found.")
        return

    np.random.seed(rand_start_index)
    building = patch_names['1']
    non_building_all =  patch_names['0']
    select_size = len(building)
    select = np.random.choice(len(non_building_all),select_size)
    non_building = [non_building_all[ii] for ii in select]

    pairs=[]
    sim_labels=[]
    sim_true = np.zeros(select_size*times, dtype=int)
    sim_false = np.ones(select_size * times, dtype=int)
    sim_all =  np.asarray(np.concatenate((sim_true, sim_false), axis=0))
    z_all = np.asarray(np.concatenate((sim_true, sim_false), axis=0))
    np.random.shuffle(sim_all) #true or false labels equal to the size of dataset
    np.random.shuffle(z_all)
    for num in range(select_size*times*2): #create select_size*times similar and dissimilar cluster data
        ind1, ind2 = np.random.randint(select_size, size=(2, 1))
        ind1 = ind1[0]
        ind2= ind2[0]
        sim = sim_all[num]
        z = z_all[num] #np.random.randint(2)

        if z==0:
            if sim:
                pairs.append((building[ind1], building[ind2]))
                sim_labels.append(1)
            else:
                pairs.append((building[ind1], non_building[ind2]))
                sim_labels.append(0)
        else:
            if sim:
                pairs.append((non_building[ind1], non_building[ind2]))
                sim_labels.append(1)
            else:
                pairs.append((non_building[ind1], building[ind2]))
                sim_labels.append(0)

    return pairs, sim_labels


def main():
    write_patches()

if __name__ == "__main__":
        main()
