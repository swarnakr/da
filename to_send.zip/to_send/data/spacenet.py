'''*************************************************************************
	> File Name: spacenet.py
	> Author: yuansong
	> Mail: yuansongwx@outlook.com
	> Created Time: Mon 21 Oct 2019 04:01:05 PM EDT
 ************************************************************************'''
import os
import numpy as np
import scipy.misc as m
import cv2
import torch
from torch.utils import data
from torchvision import transforms
import data.custom_transforms as tr
import json
from PIL import Image
import pdb
from common import config
import sys
sys.path.append(config.append_path)
import patch_dataset as pd

class Spacenet(data.Dataset):
    NUM_CLASSES = 2

    def __init__(self, city='Shanghai', split='train',im_or_patch=0):
        if 0:
            city = 'Shanghai'
            files = os.listdir(config.file_name_root + 'spacenet')
            im_list = [zz[:-8] for zz in files if (zz.startswith(city) and zz.endswith('_RGB.tif'))]
            with open('{}{}_train.json'.format(config.file_name_root,city), 'w') as f:
                json.dump(im_list, f)

        if im_or_patch:
            with open(os.path.join( config.file_name_root, '{}_{}.json'.format(city,split))) as f:
                self.img_or_patch_files = json.load(f)
            self.image_or_patch_root = config.img_root

        else:
            self.img_or_patch_files, self.label_files = pd.create_pairs(city, rand_start_index=0,split=split)
            self.image_or_patch_root  = config.patch_root + city

        self.split = split
        self.classes = [0, 1]
        self.class_names = ['bkg', 'building']

        if not self.img_or_patch_files:
            raise Exception("No files for split=[%s] found in %s" % (split, self.images_base))

        print("Found %d %s images" % (len(self.img_or_patch_files), split))

    def __len__(self):
        return len(self.img_or_patch_files)

    def __getitem__(self, index):
        if type(self.img_or_patch_files[index]) is tuple:
            img1 = Image.open(os.path.join(self.image_or_patch_root, self.img_or_patch_files[index][0])).convert('RGB')
            img2 = Image.open(os.path.join(self.image_or_patch_root, self.img_or_patch_files[index][1])).convert('RGB')
            img1 = self.convert_to_tensor(img1)
            img2 = self.convert_to_tensor(img2)
            gt_label = self.label_files[index]
            assert self.img_or_patch_files[index][0][:2]=='im'
            gt_name = 'gt' + self.img_or_patch_files[index][0][2:]
            gt_patch1 = Image.open(os.path.join(self.image_or_patch_root, gt_name))
            gt_patch1 = self.convert_to_tensor(gt_patch1)
            sample = {'image1': img1, 'image2': img2, 'label': gt_label, 'label_patch1': gt_patch1}
        else:
            img = Image.open(os.path.join(self.image_or_patch_root, self.img_or_patch_files[index] + '_RGB.tif')).convert('RGB')
            img = self.convert_to_tensor(img)
            target = Image.open(os.path.join(self.image_or_patch_root, self.img_or_patch_files[index] + '_GT.tif'))
            target = self.convert_to_tensor(target)
            sample = {'image': img, 'label': target}

        return sample
        # skip for now, may need to be included later
        # if self.split == 'train':
        #     return self.transform_tr(sample)
        # elif self.split == 'val':
        #     return self.transform_val(sample)
        # elif self.split == 'test':
        #     return self.transform_ts(sample)
    def convert_to_tensor(self,in_img):
        in_img = np.array(in_img).astype(np.float32)
        if len(in_img.shape)>2:
            in_img = in_img.transpose((2, 0, 1))
        in_img = torch.from_numpy(in_img).float()
        return in_img

    def transform_tr(self, sample):
        composed_transforms = transforms.Compose([
            tr.RandomHorizontalFlip(),
            tr.RandomVerticalFlip(),
            tr.RandomRotate(180),
            tr.RandomScaleCrop(base_size=400, crop_size=400, fill=0),
            tr.RandomGaussianBlur(),
            # tr.Normalize(),
            #tr.Normalize(mean=(0.3441, 0.3809, 0.4014), std=(0.1883, 0.2039, 0.2119)),
            tr.ToTensor(),
        ])

        return composed_transforms(sample)

    def transform_val(self, sample):

        composed_transforms = transforms.Compose([
            tr.FixScaleCrop(400),
            #tr.Normalize(mean=(0.3441, 0.3809, 0.4014), std=(0.1883, 0.2039, 0.2119)),
            # tr.Normalize(),
            tr.ToTensor()])

        return composed_transforms(sample)

    def transform_ts(self, sample):

        composed_transforms = transforms.Compose([
            tr.FixedResize(size=400),
            #tr.Normalize(mean=(0.3441, 0.3809, 0.4014), std=(0.1883, 0.2039, 0.2119)),
            # tr.Normalize(),
            tr.ToTensor()])

        return composed_transforms(sample)

if __name__ == "__main__":
    from torch.utils.data import DataLoader
    spacenet_train = Spacenet(img_root='/data/spacenet/')
    dataloader = DataLoader(spacenet_train, batch_size=2, shuffle=True, num_workers=2)
    #print(spacenet_train.__getitem__(0))
    for ii, sample in enumerate(dataloader):
        for jj in range(sample["image"].size()[0]):
            img = sample['image'][jj].numpy()
            gt = sample['label'][jj].numpy()
            img = img.transpose(1,2,0)
            gt = gt[:,:,None]
            print(img.shape)
            print(gt.shape)
            gt_ = gt.repeat(3, axis=2)
            show = np.hstack((img, gt_))
            cv2.imshow('show', show[:,:,::-1])
            c = chr(cv2.waitKey(0) & 0xff)
            if c == 'q':
                exit()





