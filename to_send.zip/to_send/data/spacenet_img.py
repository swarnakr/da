class Spacenet(data.Dataset):
    NUM_CLASSES = 2

    def __init__(self, city='Shanghai', split='train', img_root='/usr/xtmp/satellite/spacenet/'):
        self.img_root = img_root
        self.name_root = '/home/home1/swarnakr/scriptln/DA/domains/' + city; #'/home/home1/xw176/work/Domain_Adaptation/dataset/spacenet/domains/' + city
        with open(os.path.join(self.name_root, split + '.json')) as f:
            self.files = json.load(f)

        self.split = split
        self.classes = [0, 1]
        self.class_names = ['bkg', 'building']

        if not self.files:
            raise Exception("No files for split=[%s] found in %s" % (split, self.images_base))

#        pdb.set_trace()
        print("Found %d %s images" % (len(self.files), split))

    def __len__(self):
        return len(self.files)

    def __getitem__(self, index):
        #img = cv2.imread(os.path.join(self.img_root, self.files[index] + '_RGB.tif'))
        img = Image.open(os.path.join(self.img_root, self.files[index] + '_RGB.tif')).convert('RGB')
        #target = cv2.imread(os.path.join(self.img_root, self.files[index] + '_GT.tif'))
        target = Image.open(os.path.join(self.img_root, self.files[index] + '_GT.tif'))
        sample = {'image': img, 'label': target}
        #pdb.set_trace()
        if self.split == 'train':
            return self.transform_tr(sample)
        elif self.split == 'val':
            return self.transform_val(sample)
        elif self.split == 'test':
            return self.transform_ts(sample)
